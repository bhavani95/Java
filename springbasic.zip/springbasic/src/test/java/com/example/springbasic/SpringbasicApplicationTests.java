package com.example.springbasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
